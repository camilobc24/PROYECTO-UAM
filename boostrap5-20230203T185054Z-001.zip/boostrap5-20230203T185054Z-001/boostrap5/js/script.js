console.log("Hello World");
var n1 =2;
var n2= 3;
var suma = n1 + n2;
var mult = n1 * n2
console.log("El resultado es = "+suma);
console.log("El resultado de la multiplicacion es= "+mult);
var raiz = Math.sqrt(1800)
console.log("El resultado de la raiz es = "+raiz);
var n3 = 1800;
var raiz2= Math.trunc(raiz);
console.log("El resultado de la raiz en su parte entera  es = " + raiz2);

var c = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log(numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}



